#ifndef _CARD_H
#define _CARD_H

bool DiscoveryLoop();

#endif
