
**Please, start the title of the pull request with the part number involved** 
*ie: "lsm6dso: ..."*

---

### Device part numbers

Device list of the part numbers impacted by the bug. *(ie lis2mdl, lsm303agr)*

### Checklist

- [ ] improvement
- [ ] bug-fix
- [ ] other

### Description

A clear and concise description.
