---
name: "Feature Request \U0001F4A1"
about: Suggest a new idea for the project.
title: ''
labels: enhancement
assignees: ''

---

### Device part numbers

Device list of the part numbers impacted by the bug. *(ie lis2mdl, lsm303agr)*

### Summary

Brief explanation of the feature.

### Basic example

If the proposal involves a new or changed API, include a basic code example. Omit this section if it's not applicable.

### Motivation

Why are we doing this? What use cases does it support?
