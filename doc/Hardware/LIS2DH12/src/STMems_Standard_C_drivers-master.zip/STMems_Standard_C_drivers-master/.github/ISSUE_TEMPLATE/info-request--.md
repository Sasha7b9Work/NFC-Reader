---
name: Information request ❓
about: Further information request.
title: 'Start the title with the part number (ie: "lsm6dso: ..." )'
labels: question
assignees: ''

---

### Device part numbers

Device list of the part numbers impacted by the bug. *(ie lis2mdl, lsm303agr)*

### Question

A clear and concise question, which should preferably include references to code or documentation.